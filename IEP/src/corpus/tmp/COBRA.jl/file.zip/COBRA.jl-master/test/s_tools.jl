#-------------------------------------------------------------------------------------------
#=
    Purpose:    Test the tool functions
    Author:     Laurent Heirendt - LCSB - Luxembourg
    Date:       January 2017
=#

#-------------------------------------------------------------------------------------------


if !@isdefined includeCOBRA
    includeCOBRA = true
end

# output information
testFile = @__FILE__

# number of workers
nWorkers = 1

pkgDir = joinpath(dirname(pathof(COBRA)), "..")

# create a pool and use the COBRA module if the testfile is run in a loop
if includeCOBRA
    connectSSHWorkers = false
    include(pkgDir*"/src/connect.jl")

    # create a parallel pool and determine its size
    if isdefined(:nWorkers) && isdefined(:connectSSHWorkers)
        workersPool, nWorkers = createPool(nWorkers, connectSSHWorkers)
    end

    using COBRA
end

# include a common deck for running tests
include(pkgDir*"/config/solverCfg.jl")

# change the COBRA solver
solver = changeCobraSolver(solverName, solParams)

# load an external mat file
model = loadModel(pkgDir*"/test/ecoli_core_model.mat", "S", "model")

# find the reaction ID of one reaction
rxnIDs, rxnIDsNE = findRxnIDS(model, ["PPC"])
@test rxnIDs == [79]
@test rxnIDsNE == []

# find the reaction ID of all the reactions
rxnIDs, rxnIDsNE = findRxnIDS(model)
@test rxnIDs == model.rxns

# find the reaction ID of 2 reactions ("ABC" is not in the model)
rxnIDs, rxnIDsNE = findRxnIDS(model, ["PPC", "ABC"])
@test rxnIDs == [79]
@test rxnIDsNE == [2]

# find the reaction ID of 2 reactions ("ABC" is not in the model)
@test_throws ErrorException findRxnIDS(model, ["ABC"])
