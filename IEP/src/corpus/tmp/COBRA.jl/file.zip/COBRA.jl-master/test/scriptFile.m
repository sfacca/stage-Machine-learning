% define the filename of the model
modelFile = PALM_modelFile;

% define the fieldname of the stoichiometric matrix
matrixName = 'S';

model = readCbModel([PALM_dir filesep modelFile]);

S = model.S;

[nMets, nRxns] = size(S)

% determine the number of elements in S
nElem = numel(S)

% determine the number of nonzero elements in S
nNz = nnz(S)