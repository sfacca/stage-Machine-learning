# Functions

## connect.jl

```@autodocs
Modules = [COBRA]
Pages = ["connect.jl"]
```

## checkSetup.jl

```@autodocs
Modules = [COBRA]
Pages = ["checkSetup.jl"]
```

## distributedFBA.jl
```@autodocs
Modules = [COBRA]
Pages = ["distributedFBA.jl"]
```

## load.jl
```@autodocs
Modules = [COBRA]
Pages = ["load.jl"]
```

## PALM.jl
```@autodocs
Modules = [COBRA]
Pages = ["PALM.jl"]
```

## solve.jl
```@autodocs
Modules = [COBRA]
Pages = ["solve.jl"]
```

## tools.jl
```@autodocs
Modules = [COBRA]
Pages = ["tools.jl"]
```
